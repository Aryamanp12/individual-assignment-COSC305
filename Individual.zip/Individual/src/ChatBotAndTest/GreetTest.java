package ChatBotAndTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

import Jwiki.Jwiki;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;

public class GreetTest {

	public static void main(String[] args) throws IOException {
		System.out.println("Hello and welcome to our Chat bot concerning mental health.");
		ThreadSleep(2000);
		System.out.println("If you would, please enter a little bit about yourself, so that we may get to know you better.");
		Scanner input = new Scanner(System.in);
		String patientInformation = input.nextLine();
		System.out.println("And finally, please enter your name or username: ");
		String username = input.nextLine();
		username.trim();
		ChatBot chat = new ChatBot();
		chat.Greet(username, input, Tokenizing(patientInformation));
		
		
		input.close();
		
		
		
		
	}

	// Suspends the thread to give the illusion that the machine is typing out a response.
	private static void ThreadSleep(int milliseconds) {
		try {
			Thread.sleep(milliseconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static String[] Tokenizing(String patientInfo) throws IOException {
		String path = new File("src/Resources/opennlp-en-ud-ewt-tokens-1.0-1.9.3.bin").getAbsolutePath();
		
		InputStream modelIn = new FileInputStream(path);
		TokenizerModel model = new TokenizerModel(modelIn);
		if (modelIn != null) {
			try {
				modelIn.close();
			} 
			catch (IOException e) {}
		}
		TokenizerME tokenizer = new TokenizerME(model);
		String tokens[] = tokenizer.tokenize(patientInfo);
		return tokens;
	}
		
}

