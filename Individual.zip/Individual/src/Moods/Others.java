package Moods;

import java.io.IOException;
import java.util.Scanner;

import com.gtranslate.Language;
import com.gtranslate.Translator;

import InterfacesMoods.MentIllnessTherapist;
import InterfacesMoods.OtherTherapist;
import Jwiki.Jwiki;
import Therapists.TherapistConnection;

public class Others implements OtherTherapist, MentIllnessTherapist{
	public void othersInvoked(String userName) {
		Scanner standardInput = new Scanner(System.in);
		System.out.println("I'm sorry I cannot help you with your specific mood.");
		System.out.println("If you are not suffering from mental health, perhaps you would like to talk to someone about mental illnesses? \nPlease reply with a yes or no. (Y/N)");
		boolean done = false;
		while(!done) {
			String yesOrNo = (String) standardInput.next();
			if(yesOrNo.equals("Y")) {
				System.out.println("Please wait while we connect you with a therapist concerning mental illnesses.");
				TherapistConnection mentalIllnessTherapist = new TherapistConnection();
				mentalIllnessTherapist.MentIllnessTherapistInvoked(userName);
				done = true;
			}
			else if(yesOrNo.equals("N")) {
				System.out.println("It seems you do not have a mentall illness then. As such, would you like to be connected with a therapist to pinpoint"
						+ " your mood?");
				
				Scanner input = new Scanner(System.in);
				
				
				System.out.println("If you would like to know about a particular topic please enter what you would like to know about");
				String s = input.nextLine();
				Jwiki jwiki = new Jwiki(s);
				System.out.println("Here is what we found about the given topic");
				System.out.println(jwiki.getExtractText());
				
				
				Translator translate = Translator.getInstance();
				System.out.println("If you would like us to translate something to English so we could translate it for you right below enter the language you would like to translate and then your text");
				String lan = input.nextLine();
				String text = input.nextLine();
				lan.toUpperCase();
				String something = "Language.lan";
				translate.translate(text, something, Language.ENGLISH);
				System.out.println(text);
				
				
				TherapistConnection otherTherapist = new TherapistConnection();
				done = false;
				while(!done) {
					yesOrNo = (String) standardInput.next();
					if(yesOrNo.equals("Y")) {
						System.out.println("Please wait while we connect you with a therapist.");
						otherTherapist.OtherTherapistInvoked(userName);
						done = true;
						
					}
					else if(yesOrNo.equals("N")) {
						System.out.println("Thank you for using our service, " + userName + "!");
						done = true;
					}
					else {
						System.out.println("You entered a wrong character! Please try again. (Y/N)");
						done = false;
					}
				}
			}
			else {
				System.out.println("You entered a wrong character! Please try again. (Y/N)");
			}
		}
		
		standardInput.close();
	}
}
