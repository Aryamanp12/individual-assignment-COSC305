package ChatBotAndTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;
import InterfacesMoods.*;
import Moods.*;
import opennlp.tools.namefind.NameFinderME;
import opennlp.tools.namefind.TokenNameFinderModel;
import opennlp.tools.stemmer.PorterStemmer;
import opennlp.tools.util.Span;

public class ChatBot implements AnxietyInterface, DepressionInterface, EmergencyInterface, HappyInterface, OthersInterface, StressedInterface{
	public static Anxiety anxiety = new Anxiety();
	public static Depression depression = new Depression();
	public static Emergency emergency = new Emergency();
	public static Happy happy = new Happy();
	public static Others other = new Others();
	public static Stressed stress = new Stressed();
	
	public void Greet(String userName, Scanner scanner, String[] tokenizedArrayString) throws IOException {
		PorterStemmer ps = new PorterStemmer();
		System.out.println("Hello, " + userName + "! Welcome.");
		System.out.println("Please state the current theme of your issue so that I may assist you the best.");
		Scanner input = scanner;
		boolean done = false;
		while (!done) {
			String currentIssue = input.next();
			boolean depressBoolean = ps.stem(currentIssue).equals("Depress");
			boolean stressBoolean = ps.stem(currentIssue).equals("Stress");
			boolean otherBoolean = ps.stem(currentIssue).equals("Other");
			if (currentIssue.equals("Anxiety")) {
				anxiety.anxietyInvoked(userName);
				done = true;
			}
			else if(depressBoolean) {
				depression.depressionInvoked(userName);
				done = true;
			}
			else if(currentIssue.equals("Emergency")) {
				emergency.emergencyInvoked(userName);
				done = true;
			}
			else if(currentIssue.equals("Happy")) {
				happy.happyInvoked(userName);
				done = true;
			}
			else if(otherBoolean) {
				other.othersInvoked(userName);
				done = true;
			}
			else if(stressBoolean) {
				stress.stressedInvoked(userName);
				done = true;
			}
			else {
				System.out.println("You didn't enter a proper theme, try again!");
				done = false;
			}
		}
		Span nameSpans[] = NameFinder(tokenizedArrayString);
		String nameSpansToString[] = new String[nameSpans.length];
		for (int i = 0; i < nameSpans.length; i++) {
			nameSpansToString[i] = nameSpans[i].toString();
		}
		for (int i = 0; i < nameSpansToString.length; i++) {
			if (nameSpansToString[i].substring(8).equals("person")) {
				String userInfo = "They are a human being.";
			}
		}
		input.close();
		
		
	}
	
	public static Span[] NameFinder(String[] tokenizedArrayString) throws IOException {
		
		String pathNameFinder = new File("src/Resources/en-ner-person.bin").getAbsolutePath();
		InputStream modelInNameFinder = new FileInputStream(pathNameFinder);
		TokenNameFinderModel t = new TokenNameFinderModel(modelInNameFinder);
		NameFinderME nameFinder = new NameFinderME(t);
		Span nameStrings[] = nameFinder.find(tokenizedArrayString);
		
		return nameStrings;
	}
}
